
package br.com.julianoceconi.trabalho1bimpoo;

import java.util.ArrayList;
import java.util.List;

public class Venda {
    
    private double valorTotalVenda;
    private ArrayList<itemVenda> itens;
    
    public Venda(){
        this.itens = new ArrayList<>();
    }
    
    public Venda(ArrayList<itemVenda> itens){
        this.itens = itens;
        calcularValorVenda();
    }
    
    public void calcularValorVenda(){
        valorTotalVenda = 0;
        for(itemVenda item : itens){
            valorTotalVenda += item.calcularPreco();
        }
    }
    
    public void adicionarItem(itemVenda item){
        this.itens.add(item);
    }
    
    public void addFormaDePagamento(String formaPagamento){
        
    }
    
    public void atualizarEstoque(){
        for(itemVenda item : itens){
            item.diminuiQtdEstoque(item.getQuantidade());
        }
    }
    
    @Override
    public String toString() {
        StringBuilder venda = new StringBuilder();
        
        venda.append("Venda: \n");
        for (itemVenda item : itens) {
            venda.append(item.toString()).append("\n");
        }
        
        venda.append("\nValor Total da Venda = R$ ").append(valorTotalVenda);
        return venda.toString();
    }
}
