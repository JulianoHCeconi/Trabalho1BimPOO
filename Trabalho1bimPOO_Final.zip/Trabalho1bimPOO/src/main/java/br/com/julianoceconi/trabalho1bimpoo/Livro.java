
package br.com.julianoceconi.trabalho1bimpoo;

public class Livro {

    private String titulo;
    private String editora;
    private int anoLancamento;
    private String autor;
    private String genero;
    private int qtdPaginas;
    private double preco;
    
    public Livro(String titulo, String editora, int anoLancamento, String autor,
            String genero, int qtdPaginas, double preco){
        
        this.anoLancamento = anoLancamento;
        this.editora = editora;
        this.autor = autor;
        this.genero = genero;
        this.preco = preco;
        this.qtdPaginas = qtdPaginas ;
        this.titulo = titulo;
               
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getEditora() {
        return editora;
    }

    public void setEditora(String editora) {
        this.editora = editora;
    }

    public int getAnoLancamento() {
        return anoLancamento;
    }

    public void setAnoLancamento(int anoLancamento) {
        this.anoLancamento = anoLancamento;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public int getQtdPaginas() {
        return qtdPaginas;
    }

    public void setQtdPaginas(int qtdPaginas) {
        this.qtdPaginas = qtdPaginas;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }
    
    @Override 
    public String toString() {
        return "" + 
                " Titulo = " + titulo + 
                ", Editora = " + editora + 
                ", Ano Lancamento = " + anoLancamento + 
                ", Autor = " + autor + 
                ", Genero = " + genero + 
                ", Quantidade de Paginas = " + qtdPaginas + 
                ", Preco = R$ " + preco;
    }     
}
