
package br.com.julianoceconi.trabalho1bimpoo;

public class Cliente {
    
    private String nome;
    private String cpf;
    private String nrTelefone;
    
    public Cliente(String nome, String cpf, String nrTelefone){
            
        this.cpf = cpf;
        this.nome = nome;
        this.nrTelefone = nrTelefone;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getNrTelefone() {
        return nrTelefone;
    }

    public void setNrTelefone(String nrTelefone) {
        this.nrTelefone = nrTelefone;
    }

    @Override
    public String toString() {
        return "Cliente: " + 
                " Nome = " + nome + 
                ", CPF = " + cpf + 
                ", Numero de Telefone = " + nrTelefone;
    }
}
