
package br.com.julianoceconi.trabalho1bimpoo;

public class FormaDePagamento {
    
    private String metodoPagar;
    
    public FormaDePagamento(String metodoPagar){  
        this.metodoPagar = metodoPagar;
    }

    public String getMetodoPagar() {
        return metodoPagar;
    }

    public void setMetodoPagar(String metodoPagar) {
        this.metodoPagar = metodoPagar;
    }

    @Override
    public String toString() {
        return "Forma De Pagamento: " + 
                "Metodo escolhido = " + metodoPagar;
    }

   
     
}
