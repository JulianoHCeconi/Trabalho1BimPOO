
package MAIN;

import br.com.julianoceconi.trabalho1bimpoo.*;
import java.util.ArrayList;

public class ClasseMain {
    
    public static void main(String[] args){
        
        //Criando Livros
        
        Livro livro1 = new Livro("Chapeuzinho Vermelho", "Editora Cassol", 
        1697, "Charles Perrault", "Conto de Fadas", 32, 27.75);
        
        Livro livro2 = new Livro("Dois Mundos Um Herói", "Suma Editora", 2015,
        "RezendeEvil", "Ficção e Fantasia", 144, 59.90);
            
        Livro livro3 = new Livro("O Senhor dos Anéis", "Martins Fontes", 2000,
        "J.R.R TOLKIEN", "Ficção e Fantasia", 464, 70.95);
        
        // Criando Cliente
        Cliente cliente = new Cliente("Roberson do Nascimento", "115.404.659-18",
        "(44) 9 9689-1345");
        
        // Criando Endereço
        Endereco endereco = new Endereco("Rua Juscelino Kubitschek", "85408-970",
        "Centro", "Diamante do Sul", 33, "Paraná - PR", "Brasil");
        
        // Criando Itens vendidos
        itemVenda item1 = new itemVenda(livro1, 7, 10.0, 20);
        itemVenda item2 = new itemVenda(livro2, 36, 20.0, 50);
        itemVenda item3 = new itemVenda(livro3, 67, 15.0, 90);
        
        ArrayList<itemVenda> itens = new ArrayList<>();
        itens.add(item1);
        itens.add(item2);
        itens.add(item3);
        
        Venda venda = new Venda(itens);
       
        venda.atualizarEstoque();
        
        // Criando forma de pagamento
        venda.addFormaDePagamento("Pix");
        venda.addFormaDePagamento("Dinheiro");
        
        System.out.println("Detalhes do cliente: ");
        System.out.println(cliente + "\n" +
                            endereco);
        
        System.out.println("\nDetalhes da venda: ");
        System.out.println(venda);
        
        System.out.println("Forma de Pagamento: " + "Pix");
    }
   }