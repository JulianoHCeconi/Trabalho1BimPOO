
package br.com.julianoceconi.trabalho1bimpoo;

public class itemVenda {
    
    private Livro livro;
    private int quantidade;
    private double valorDesconto;
    private int qtdEstoque;
    
    public itemVenda(Livro livro, int quantidade, double valorDesconto, 
            int qtdEstoque){
        
        this.livro = livro;
        this.quantidade = quantidade;
        this.valorDesconto = valorDesconto;
        this.qtdEstoque = qtdEstoque;
    }
    
    public itemVenda(){
    }

    public int getQtdEstoque(){
        return qtdEstoque;
    }

    public void setQtdEstoque(int qtdEstoque){
        this.qtdEstoque = qtdEstoque;
    }
    
    public Livro getLivro() {
        return livro;
    }

    public void setLivro(Livro livro){
        this.livro = livro;
    }

    public int getQuantidade(){
        return quantidade;
    }

    public void setQuantidade(int quantidade){
        this.quantidade = quantidade;
    }

    public double getValorDesconto(){
        return valorDesconto;
    }

    public void setValorDesconto(double valorDesconto){
        this.valorDesconto = valorDesconto;
    }
    
    public double calcularPreco(){
        return (livro.getPreco() - valorDesconto) * quantidade;
    }
    
    public void diminuiQtdEstoque(int quantidade){
        if(quantidade > this.qtdEstoque){
            System.out.println("Quantidade informada maior que o estoque!");
            return;
        }
        this.qtdEstoque -= quantidade;
    }

    @Override
    public String toString() {
        return "itemVenda: " + 
                "Livro = " + livro + 
                ", Quantidade da compra = " + quantidade +
                ", Valor de Desconto(R$) = " + valorDesconto +
                ", Quatidade de Estoque após a venda = " + qtdEstoque;
    }  
}
